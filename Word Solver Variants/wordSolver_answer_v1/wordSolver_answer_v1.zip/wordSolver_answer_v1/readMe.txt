To use the wordle solver:

When prompted for each of the following, enter the grey, yellow, and green letters such that they match up with the proper placement within the results received from Wordle. Example Below:

Only lower case letters will be accepted!
----------------------------------------------------------------

My first guess: raise
My first Results: r(grey) a(yellow) i(grey) s(grey) e(green)

When prompted for grey letters, I enter: 
"r is " (without the quotes)

When prompted for yellow letters, I enter: 
" a   " (without the quotes)

When prompted for green letters, I enter: 
"    e" (without the quotes)

----------------------------------------------------------------

If entered in the order received, it should work just fine!

(Hint: you actually don't need the proper received order for the grey letters but it matters for yellow and green!)